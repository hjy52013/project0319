# ArithmeticAPP
Homework of Software Engineering Course
